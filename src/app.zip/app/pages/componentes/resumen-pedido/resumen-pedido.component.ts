import { Component, EventEmitter, Input, Output, OnChanges } from '@angular/core';

@Component({
  selector: 'app-resumen-pedido',
  templateUrl: './resumen-pedido.component.html',
  styleUrls: ['./resumen-pedido.component.scss']
})
export class ResumenPedidoComponent implements OnChanges {
  @Input() pedido: any[] = [];
  @Input() total: number = 0;
  @Input() cliente: string = '';

  @Output() clienteChange = new EventEmitter<string>();
  @Output() quitar = new EventEmitter<any>();
  @Output() confirmar = new EventEmitter<void>();
  @Output() cancelarP = new EventEmitter<void>();

  ngOnChanges() {
    // inicializar flags por item
    this.pedido.forEach(p => {
      p.editandoComentario = false;
      p.editandoDescuento = false;
    });
  }

  actualizarComentario() {
    this.clienteChange.emit(this.cliente);
  }

  eliminar(item: any) {
    this.quitar.emit(item);
  }

  toggleComentario(item: any) {
    item.editandoComentario = !item.editandoComentario;
    item.editandoDescuento = false;
  }

  toggleDescuento(item: any) {
    item.editandoDescuento = !item.editandoDescuento;
    item.editandoComentario = false;
  }

  contarItems(): number {
    return this.pedido.reduce((sum, p) => sum + p.cantidad, 0);
  }

  calcularTotal(): number {
    return this.pedido.reduce((sum, p) => {
      const descuento = p.descuento || 0;
      return sum + (p.precio - descuento) * p.cantidad;
    }, 0);
  }

  confirmarPedido() {
    this.confirmar.emit();
  }
}
