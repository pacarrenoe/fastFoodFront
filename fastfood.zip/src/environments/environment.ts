export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAe3i2RhtRCxZEiyOwf8Y1YUSP6KpaWMNU",
    authDomain: "fastfoodfront.firebaseapp.com",
    projectId: "fastfoodfront",
    storageBucket: "fastfoodfront.firebasestorage.app",
    messagingSenderId: "197581072926",
    appId: "1:197581072926:web:c0d418a80453d104e29c0f",
    measurementId: "G-QS0YPK8FZK"
  }
};
